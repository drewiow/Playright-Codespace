import { marked } from "/vendor/marked/lib/marked.esm.js";
import { ADVANCED_ACTION_SETS } from "./advanced/advancedActions.js";

const artifactList = document.getElementById("artifactList");
const logContainer = document.getElementById("logContainer");
const runnerRoot = document.getElementById("runnerRoot");
const backBtn = document.getElementById("wizardBackBtn");
const nextBtn = document.getElementById("wizardNextBtn");
const parts = window.location.pathname.split("/");
const product = parts[2];
const scriptId = parts[3];
let currentCsvRows = [];
let wizardStarted = false;
let lastLogLength = 0;
let runTimer = null;


if (!product || !scriptId) {
    console.error("Missing product or script in URL", parts);
}

document.addEventListener("DOMContentLoaded", () => {
    initRunner();
    runnerRoot.classList.add("wizard-mode");
});

let wizardState = {
    stepIndex: 0,
    steps: [],
    env: { ready: false },
    csv: { ready: false },
    options: { ready: true },
    advanced: { ready: true },
};

const wizardData = {
    env: {},
    inputs: {},
    csv: {},
    columnMappings: {}
};

const WIZARD_STEP_META = {
    env: {
        title: "Unlock access",
        subtitle: "Provide your encrypted environment file and passphrase to continue"
    },

    csv: {
        title: "Select data",
        subtitle: "Choose the CSV file that defines the records this script will process"
    },

    mappings: {
        title: "Map CSV columns",
        subtitle: "Map the columns in your CSV to the fields this script requires"
    },
    inputs: {
        title: "Script inputs",
        subtitle: "Enter the information required by this script to run correctly"
    },

    actions: {
        title: "Automation steps",
        subtitle: "Define the actions this script should perform"
    },

    behaviour: {
        title: "Run behaviour",
        subtitle: "Control how the automation behaves while it runs"
    },

    review: {
        title: "Review & run",
        subtitle: "Check your selections before starting the automation"
    }
};

document
    .getElementById("startWizardBtn")
    .addEventListener("click", () => {
        wizardStarted = true;
        document.getElementById("scriptOverview").classList.add("hidden");
        document.getElementById("wizardContainer").classList.remove("hidden");

        document
            .getElementById("runnerRoot")
            .classList.add("wizard-mode");

        wizardState.stepIndex = 0;
        renderWizardStep();
    });

function normaliseHeader(header) {
    return header
        .trim()
        .toUpperCase()
        .replace(/\s+/g, "_");
}

function parseCSV(text) {
    const lines = text.trim().split(/\r?\n/);

    const splitLine = (line) =>
        line.match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g)
            ?.map(v => v.replace(/^"|"$/g, "").trim()) || [];

    const rawHeaders = splitLine(lines[0]);
    const headers = rawHeaders.map(normaliseHeader);

    return lines.slice(1).map(line => {
        const cols = splitLine(line);
        const row = {};

        headers.forEach((key, i) => {
            row[key] = cols[i];
        });

        return row;
    });
}

function renderWizardHeader() {
    const headerEl = document.getElementById("wizardHeader");
    if (!headerEl) return;

    const stepKey = getCurrentStep();
    const stepMeta = WIZARD_STEP_META[stepKey];

    const stepIndex = wizardState.stepIndex + 1;
    const totalSteps = wizardState.steps.length;

    headerEl.innerHTML = `
        <div class="wizard-header-inner">
            <div class="wizard-progress">
                Step ${stepIndex} of ${totalSteps}
            </div>
            <div class="wizard-title">
                ${stepMeta?.title ?? stepKey}
            </div>
            <div class="wizard-subtitle">
                ${stepMeta?.subtitle ?? ""}
            </div>
        </div>
    `;
}

function goToNextStep() {

    const step = getCurrentStep();

    const statusEl = document.getElementById("stepStatus");
    if (statusEl) {
        statusEl.classList.add("hidden");
        statusEl.innerHTML = "";
    }


    if (step === "env") {
        if (!areEnvInputsValid()) {
            alert("Please upload your .enc file and enter the passphrase.");
            return;
        }
    }


    wizardState.stepIndex++;
    renderWizardStep();
}

function isCurrentStepValid() {
    const step = getCurrentStep();

    switch (step) {
        case "env":
            return areEnvInputsValid();

        case "inputs":
            return areInputsValid();

        case "csv":
            return areCsvInputsValid();

        default:
            return true;
    }
}

function updateNextButtonState() {
    const nextBtn = document.getElementById("wizardNextBtn");

    if (!nextBtn) return;

    const isValid = isCurrentStepValid();

    nextBtn.disabled = !isValid;

    // Optional: hide instead of disable
    // nextBtn.style.display = isValid ? "" : "none";
}

document.addEventListener("input", updateNextButtonState);
document.addEventListener("change", updateNextButtonState);

function showStepStatus(message) {
    const statusEl = document.getElementById("stepStatus");

    if (!statusEl) return;

    statusEl.innerHTML = `✅ ${message}`;
    statusEl.classList.remove("hidden");
}

function areCsvInputsValid() {
    let valid = true;

    const statusEl = document.getElementById("inputsStatus");
    const script = window.currentScript;
    const csvFile = document.getElementById("csvFile")?.files?.length;
    const rows = window.currentCsvRows;

    if (!rows || rows.length === 0) {
        return false;
    }
    if (!areColumnMappingsValid()) {
        return false;
    }

    showStepStatus(`CSV loaded (${rows.length} rows)`);

    return csvFile || script?.requiresCsv !== true;

}

function areEnvInputsValid() {
    const envFile = document.getElementById("runnerEnvFile")?.files?.length;
    const passphrase = document.getElementById("decryptPassword")?.value;
    const script = window.currentScript;

    const requiresEnv = script?.requiresEnvFile === true;

    if (requiresEnv && (!envFile || !passphrase)) {
        return false;
    }

    return true;
}

function areInputsValid() {

    const statusEl = document.getElementById("stepStatus");

    if (!window.currentScriptMeta?.inputs) {
        return true;
    }

    let valid = true;
    const values = {};

    window.currentScriptMeta.inputs.forEach(input => {

        const el = document.getElementById(`input-${input.key}`);

        if (!el) {
            console.warn(`Missing element: input-${input.key}`);
            valid = false;
            return;
        }

        const isCheckbox = el.type === "checkbox";

        const value = isCheckbox
            ? el.checked
            : (el.value || "").trim();

        const isValid = isCheckbox
            ? (!input.required || el.checked)
            : (!input.required || value !== "");
        console.log(`Input ${input.key}: value="${value}", required=${input.required}, valid=${isValid}`);
        if (!isValid) {
            valid = false;
            el.classList.add("input-error");
        } else {
            el.classList.remove("input-error");
        }

        values[input.key] = value;
    });

    if (!valid) {
        statusEl.classList.add("hidden");
        return false;
    }

    wizardData.inputs = values;
    //saveColumnMappings();

    console.log(values);

    statusEl.innerHTML = `
        ✅ Step complete<br>
        ${Object.entries(values)
            .map(([k, v]) => `${k}: ${v}`)
            .join("<br>")}
    `;

    statusEl.classList.remove("hidden");

    return true;
}

function goToPreviousStep() {
    if (wizardState.stepIndex > 0) {
        wizardState.stepIndex--;
        renderWizardStep();
    }
}

if (backBtn) {
    backBtn.addEventListener("click", goToPreviousStep);
}

if (nextBtn) {
    nextBtn.addEventListener("click", goToNextStep);
}

function renderWizardStep() {
    if (!wizardStarted) return;
    const step = getCurrentStep();

    // Panels
    const envPanel = document.getElementById("envPanel");
    const csvPanel = document.getElementById("csvPanel");
    const advancedPanel = document.getElementById("advancedPanel");
    const optionsPanel = document.querySelector(".options-panel");
    const inputsPanel = document.getElementById("inputsPanel");
    const actionsPanel = document.getElementById("actionsPanel");
    const behaviourPanel = document.getElementById("behaviourPanel");
    const reviewPanel = document.getElementById("reviewPanel");

    // Navigation buttons
    const backBtn = document.getElementById("wizardBackBtn");
    const nextBtn = document.getElementById("wizardNextBtn");
    const runBtn = document.getElementById("runScriptBtn");

    // ---- Hide all panels first ----
    if (envPanel) envPanel.style.display = "none";
    if (csvPanel) csvPanel.style.display = "none";
    if (advancedPanel) advancedPanel.style.display = "none";
    if (optionsPanel) optionsPanel.style.display = "none";
    if (inputsPanel) inputsPanel.style.display = "none";
    if (actionsPanel) actionsPanel.style.display = "none";
    if (behaviourPanel) behaviourPanel.style.display = "none";
    if (reviewPanel) reviewPanel.style.display = "none";

    renderWizardHeader();

    // ---- Step-specific panels ----
    if (step === "env") {
        if (envPanel) envPanel.style.display = "";
    }

    if (step === "csv") {
        if (csvPanel) csvPanel.style.display = "";
    }

    if (step === "inputs") {
        if (inputsPanel && window.hasScriptInputs) {
            inputsPanel.style.display = "";
        }
    }

    if (step === "options") {
        if (optionsPanel) optionsPanel.style.display = "";
        if (advancedPanel) advancedPanel.style.display = "";
    }

    if (step === "actions") {
        if (actionsPanel) actionsPanel.style.display = "";
    }

    if (step === "behaviour") {
        if (behaviourPanel) behaviourPanel.style.display = "";
    }

    if (step === "review") {
        renderReview();

        if (envPanel) envPanel.style.display = "none";
        if (csvPanel) csvPanel.style.display = "none";
        if (optionsPanel) optionsPanel.style.display = "none";
        if (advancedPanel) advancedPanel.style.display = "none";
        if (reviewPanel) reviewPanel.style.display = "";
    }

    // ---- Navigation visibility ----
    if (backBtn) {
        backBtn.style.display =
            wizardState.stepIndex === 0 ? "none" : "";
    }

    if (nextBtn) {
        nextBtn.style.display =
            step === "review" ? "none" : "";
    }

    if (runBtn) {
        runBtn.style.display =
            step === "review" ? "" : "none";
    }
}

async function loadScriptMeta(product, scriptId) {
    const res = await fetch(`/scripts/${product}/${scriptId}/meta.json`);
    const meta = await res.json();

    window.currentScriptMeta = meta;
    window.hasScriptInputs =
        Array.isArray(meta.inputs) && meta.inputs.length > 0;

    renderScriptInputs(meta);
    maybeInsertInputsStep();
}

function renderSpeechSupport(
    inputEl,
    buttonEl,
    orbEl
) {

    const SpeechRecognition =
        window.SpeechRecognition ||
        window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
        buttonEl.style.display = "none";
        return;
    }

    const recognition = new SpeechRecognition();

    recognition.lang = "en-GB";
    recognition.interimResults = true;

    recognition.onstart = () => {

        orbEl.classList.add("listening");

        buttonEl.classList.add("listening");
        buttonEl.textContent =
            "🔴 Listening...";
    };

    recognition.onresult = (event) => {

        inputEl.value =
            event.results[0][0].transcript;

        inputEl.dispatchEvent(
            new Event("input", {
                bubbles: true
            })
        );

        buttonEl.textContent =
            "🧠 Understanding...";
    };

    recognition.onend = () => {

        orbEl.classList.remove("listening");

        buttonEl.classList.remove("listening");
        buttonEl.textContent =
            "✅ Request Captured";

        setTimeout(() => {
            buttonEl.textContent =
                "🎙️ Ask PinnacleAI";
        }, 2000);
    };

    recognition.onerror = () => {

        buttonEl.classList.remove("listening");
        buttonEl.textContent =
            "🎙️ Ask PinnacleAI";
    };

    buttonEl.addEventListener(
        "click",
        () => recognition.start()
    );
}



function renderScriptInputs(meta) {
    const container = document.getElementById("scriptInputs");
    if (!container) return;

    container.innerHTML = "";

    if (!Array.isArray(meta.inputs) || meta.inputs.length === 0) {
        return;
    }

    meta.inputs.forEach(input => {

        const field = document.createElement("div");
        field.className = "field";

        const label = document.createElement("label");
        label.textContent = input.label;
        label.setAttribute("for", `input-${input.key}`);

        let control;

        switch (input.type) {

            case "speech-to-text": {

                const wrapper = document.createElement("div");
                wrapper.className = "speech-input";

                const textBox = document.createElement("input");
                textBox.type = "text";
                textBox.id = `input-${input.key}`;
                textBox.name = input.key;
                textBox.placeholder =
                    input.placeholder || "Ask PinnacleAI...";

                const controls = document.createElement("div");
                controls.className = "speech-controls";

                const orb = document.createElement("div");
                orb.className = "ai-orb";
                orb.id = `orb-${input.key}`;

                const micButton = document.createElement("button");
                micButton.type = "button";
                micButton.className = "mic-btn";
                micButton.textContent = "🎙️ Ask PinnacleAI";

                controls.appendChild(orb);
                controls.appendChild(micButton);

                wrapper.appendChild(textBox);
                wrapper.appendChild(controls);

                renderSpeechSupport(
                    textBox,
                    micButton,
                    orb
                );

                field.appendChild(label);
                field.appendChild(wrapper);

                container.appendChild(field);

                return;
            }

            case "checkbox":

                field.innerHTML = `
                    <label style="display:flex;align-items:center;gap:8px;">
                        <input
                            type="checkbox"
                            id="input-${input.key}"
                            name="${input.key}">
                        ${input.label}
                    </label>
                `;

                container.appendChild(field);
                return;

            case "select":

                control = document.createElement("select");

                if (Array.isArray(input.options)) {
                    input.options.forEach(opt => {
                        const option = document.createElement("option");
                        option.value = opt.value ?? opt;
                        option.textContent = opt.label ?? opt;
                        control.appendChild(option);
                    });
                }

                break;

            case "textarea":

                const wrapper = document.createElement("div");
                wrapper.style.display = "flex";
                wrapper.style.flexDirection = "column";
                wrapper.style.gap = "12px";

                // Editor
                control = document.createElement("textarea");
                control.id = `input-${input.key}`;
                control.name = input.key;

                if (input.placeholder) {
                    control.placeholder = input.placeholder;
                }

                if (input.required) {
                    control.required = true;
                }
                control.style.width = "100%";
                control.style.minHeight = "250px";

                const previewLabel = document.createElement("div");
                previewLabel.textContent = "Preview";
                previewLabel.style.fontWeight = "600";
                previewLabel.style.color = "#555";

                // Preview container
                const previewContainer = document.createElement("div");
                previewContainer.style.display = "flex";
                previewContainer.style.justifyContent = "center";


                // Preview panel
                const preview = document.createElement("div");

                preview.style.width = "100%";
                preview.style.maxWidth = "640px";
                preview.style.minHeight = "200px";

                preview.style.padding = "18px";

                preview.style.background = "#ffffff";
                preview.style.border = "1px solid #cfcfcf";
                preview.style.borderRadius = "4px";
                preview.style.boxShadow = "0 2px 6px rgba(0,0,0,0.2)";

                preview.style.boxSizing = "border-box";
                preview.style.overflowY = "auto";

                preview.style.fontFamily = "Arial, Helvetica, sans-serif";
                preview.style.fontSize = "14px";
                preview.style.lineHeight = "1.6";
                preview.style.color = "#666";

                previewContainer.appendChild(preview);

                function renderBBCode(text) {

                    let html = text;

                    // Bold
                    html = html.replace(
                        /\[b\](.*?)\[\/b\]/gi,
                        "<strong>$1</strong>"
                    );

                    // Links with text
                    html = html.replace(
                        /\.*?\[\/url\]/gi,
                        '$1'
                    );

                    // Bare links
                    html = html.replace(
                        /\.*?\[\/url\]/gi,
                        '$1$1</a>'
                    );

                    // Images
                    html = html.replace(
                        /\.*?\[\/img\]/gi,
                        '" style="max-width:100%; max-height:250px;">'
                    );

                    // Non-breaking spaces
                    html = html.replace(
                        /\[\s\]/g,
                        "&nbsp;"
                    );

                    // Bullets
                    html = html.replace(
                        /\[\.\]\s*/g,
                        "• "
                    );

                    // Indented dash bullets
                    html = html.replace(
                        /(^|<br>)\s*-\s*/g,
                        "$1&nbsp;&nbsp;&nbsp;• "
                    );

                    // Line breaks LAST
                    html = html.replace(
                        /\[br\]/gi,
                        "<br>"
                    );

                    return html;
                }

                function updatePreview() {

                    const titleInput =
                        document.querySelector('[name="TITLE"]') ||
                        document.querySelector('#input-title');

                    const title = titleInput?.value || "Announcement Title";

                    preview.innerHTML = `
        <div style="
            font-size:20px;
            font-weight:600;
            color:#444;
            margin-bottom:16px;
            border-bottom:1px solid #ddd;
            padding-bottom:10px;
        ">
            ${title}
        </div>

        <div>
            ${renderBBCode(control.value)}
        </div>
    `;
                }

                control.addEventListener("input", updatePreview);

                wrapper.appendChild(control);
                wrapper.appendChild(previewLabel);
                wrapper.appendChild(previewContainer);

                field.appendChild(label);
                field.appendChild(wrapper);

                container.appendChild(field);

                return;

            default:

                control = document.createElement("input");
                control.type = input.type || "text";
        }

        control.id = `input-${input.key}`;
        control.name = input.key;

        if (input.placeholder) {
            control.placeholder = input.placeholder;
        }

        if (input.required) {
            control.required = true;
        }

        field.appendChild(label);
        field.appendChild(control);

        container.appendChild(field);
    });
}

function maybeInsertInputsStep() {
    if (!window.hasScriptInputs) return;

    const steps = wizardState.steps;

    // Prefer inserting before actions, otherwise before review
    const insertIndex = steps.includes("actions")
        ? steps.indexOf("actions")
        : steps.indexOf("review");

    if (!steps.includes("inputs")) {
        steps.splice(insertIndex, 0, "inputs");
    }
}

function getCurrentStep() {
    return wizardState.steps[wizardState.stepIndex];
}

function getWizardSteps(script) {
    const steps = [];

    // 1. Credentials / Unlock
    if (script.requiresEnvFile || script.requiresPassword) {
        steps.push("env");
    }

    // 2. Data source
    if (script.requiresCsv) {
        steps.push("csv");
    }

    // 3. Script-specific inputs (manifest-driven)
    // These define WHAT the script operates on
    if (script.inputs && script.inputs.length > 0) {
        steps.push("inputs");
    }

    // 4. Automation / Actions
    // Defines WHAT actions are performed per row or run
    if (script.actions || script.advanced) {
        steps.push("actions");
    }

    // 5. Run behaviour / Execution options
    // Defines HOW the automation behaves (safety, visibility, speed)
    if (script.showOptionsPanel) {
        steps.push("behaviour");
    }

    // 6. Final confirmation
    steps.push("review");

    return steps;
}
function areColumnMappingsValid() {
    const requiredColumns = window.currentScriptMeta?.requiredColumns;

    if (!requiredColumns?.length) {
        return true;
    }

    return requiredColumns
        .filter(column => column.required)
        .every(column =>
            wizardData.columnMappings[column.key]
        );
}

async function initRunner() {

    const parts = window.location.pathname.split("/");

    // parts[0] = ""
    // parts[1] = "run"
    // parts[2] = product
    // parts[3] = scriptId

    const product = parts[2];
    const scriptId = parts[3];

    if (!product || !scriptId) {
        console.error("Missing product or script in URL", parts);
    }

    try {
        const manifest = await loadManifest(product);
        const script = manifest.scripts.find(s => s.id === scriptId);

        document.getElementById("metaScript").textContent =
            script.title || script.name || script.id;

        document.getElementById("metaProduct").textContent =
            manifest.title || manifest.name || product;


        window.currentScript = script;
        wizardState.steps = getWizardSteps(script);
        wizardState.stepIndex = 0;

        if (!script) {
            console.error("Script not found in manifest:", scriptId);
            return;
        }

        const productName = manifest?.name || manifest?.title || product;
        document.getElementById("breadcrumb").innerHTML =
            `Automation Runner <span class="crumb-sep">→</span > ${productName} <span class="crumb-sep">→</span> ${script.title || script.name || script.id} `;

        applyScriptRequirements(script);
        populateHeader(manifest, script);
        populateDescription(product, script);
        loadScriptMeta(product, scriptId);
        setupRunForm(product, script);
        SetupAdvancedUI();
        await loadManifest(product);
        renderWizardStep();

    } catch (err) {
        console.error("Runner init failed:", err);
    }
}

function resolveAdvancedActions(script) {
    const setName = script?.advancedOptions?.actionSet || "default";
    return ADVANCED_ACTION_SETS[setName] || ADVANCED_ACTION_SETS.default;
}

function saveColumnMappings() {

    wizardData.columnMappings = {};

    document
        .querySelectorAll(
            "#columnMappings select"
        )
        .forEach(select => {

            wizardData.columnMappings[
                select.dataset.key
            ] = select.value;

        });

    console.log(
        "Mappings before submit:",
        wizardData.columnMappings
    );
}

function SetupAdvancedUI() {
    const inlineTextarea = document.getElementById("advancedSteps");

    function initAdvancedHelp() {
        const panel = document.getElementById("advanced-help-panel");
        const content = document.getElementById("advanced-help-content");
        const toggleBtn = document.getElementById("advanced-help-toggle");
        const closeBtn = document.getElementById("advanced-help-close");

        if (!panel || !content || !toggleBtn || !closeBtn) return;

        toggleBtn.addEventListener("click", () => {
            panel.classList.remove("hidden");
            panel.setAttribute("aria-hidden", "false");
        });

        closeBtn.addEventListener("click", () => {
            panel.classList.add("hidden");
            panel.setAttribute("aria-hidden", "true");
        });

        renderAdvancedHelpContent(content);
    }

    const ADVANCED_HELP_SECTIONS = [
        {
            title: "Quick Start",
            body: `
Advanced Mode runs one step per line, in order.

        Example:
    type #email user @example.com
click #save
    wait.result
        `.trim(),
        },
        {
            title: "Commands",
            body: `
    click < selector >
        type < selector > <text>
            wait <selector>
                select <selector> <option>
                    press <key>
                        `.trim(),
        },
        {
            title: "Selectors",
            body: `
                        #id           → best when available
                        .class        → use carefully
                        [name=email]  → very reliable
                        text=Save     → use as a fallback
                        `.trim(),
        }
    ];

    const ADVANCED_PRESETS = [
        {
            id: "update-migration", label: "Update migration table", steps: `goto /admin/web?migrations&new
wait #inODSCode
type #inODSCode {{WITHCOV}}
type #inPreviousODSCode {{ODSCODE}}
select #inPreviousInstance prim
#click #saveMigration
click #saveMigration`
        }
    ];

    const presetSelect = document.getElementById("advancedTemplateSelect");

    ADVANCED_PRESETS.forEach(preset => {
        const opt = document.createElement("option");
        opt.value = preset.id;
        opt.textContent = preset.label;
        presetSelect.appendChild(opt);
    });



    const csvFileInput = document.getElementById("csvFile");

    function renderAdvancedHelpContent(container) {
        container.innerHTML = "";

        ADVANCED_HELP_SECTIONS.forEach((section) => {
            const sectionEl = document.createElement("section");

            const title = document.createElement("h4");
            title.textContent = section.title;

            const pre = document.createElement("pre");
            pre.textContent = section.body;

            sectionEl.appendChild(title);
            sectionEl.appendChild(pre);

            if (section.insertable) {
                const insertBtn = document.createElement("button");
                insertBtn.textContent = "Insert Example";
                insertBtn.addEventListener("click", () =>
                    insertSteps(section.body)
                );
                sectionEl.appendChild(insertBtn);
            }

            container.appendChild(sectionEl);
        });
    }

    function renderAdvancedActions(groups, containerEl, textareaEl) {
        containerEl.innerHTML = "";

        groups.forEach(group => {
            // Group header
            const heading = document.createElement("button");
            heading.type = "button";
            heading.className = "advanced-action-group-title";
            heading.textContent = `▶ ${group.group} `;

            // Group container (collapsed by default)
            const groupContainer = document.createElement("div");
            groupContainer.className = "advanced-action-group";
            groupContainer.style.display = "none";

            // Toggle behaviour
            heading.addEventListener("click", () => {
                const expanded = groupContainer.style.display === "block";
                groupContainer.style.display = expanded ? "none" : "block";
                heading.textContent = `${expanded ? "▶" : "▼"} ${group.group} `;
            });

            // Render actions
            group.actions.forEach(action => {
                const btn = document.createElement("button");
                btn.type = "button";
                btn.className = "advanced-action-btn";
                btn.textContent = action.label;

                btn.addEventListener("click", () => {
                    insertSteps(textareaEl, action.steps.trim());
                });

                groupContainer.appendChild(btn);
            });

            containerEl.appendChild(heading);
            containerEl.appendChild(groupContainer);
        });
    }

    const actionsContainer = document.getElementById("advancedActions");
    const actions = resolveAdvancedActions(window.currentScript);

    renderAdvancedActions(
        actions,
        actionsContainer,
        inlineTextarea
    );



    function renderTokenPanel(headers) {
        console.log("[Tokens] rendering", headers);

        const tokenListEl = document.getElementById("advancedTokenList");
        if (!tokenListEl) return;

        tokenListEl.innerHTML = "";

        headers.forEach(header => {
            const btn = document.createElement("button");

            btn.type = "button";
            btn.textContent = `{{${header}}}`;

            btn.addEventListener("click", () => {
                insertSteps(
                    inlineTextarea,
                    `{{${header}}} `
                );
            });

            tokenListEl.appendChild(btn);
        });
    }

    function insertSteps(textarea, text) {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;

        const normalized = text.trim() + "\n";

        textarea.value =
            textarea.value.slice(0, start) +
            normalized +
            textarea.value.slice(end);

        const pos = start + normalized.length;
        textarea.selectionStart = textarea.selectionEnd = pos;
        textarea.focus();
        updateHighlight();

    }

    if (csvFileInput) {
        csvFileInput.addEventListener("change", (e) => {
            handleCsvSelected(e);
        });
    }

    document.querySelectorAll("[data-action]").forEach(btn => {
        btn.addEventListener("click", () => {
            const action = ADVANCED_ACTIONS[btn.dataset.action];
            if (!action) return;

            insertSteps(inlineTextarea, action.steps);
        });
    });

    presetSelect.addEventListener("change", () => {
        const preset = ADVANCED_PRESETS.find(p => p.id === presetSelect.value);
        if (!preset) return;

        inlineTextarea.value = preset.steps;
        presetSelect.value = "";
    });

    const tokenListEl = document.getElementById("advancedTokenList");

    let csvHeaders = [];
    const TOKEN_REGEX = /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g;

    function handleCsvSelected(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();

        reader.onload = () => {
            const text = reader.result;

            // ✅ Parse headers AND rows
            const headers = parseCsvHeaders(text);
            const rows = parseCSV(text);

            currentCsvRows = rows;
            csvHeaders = headers;

            // ✅ Store globally
            window.currentCsvHeaders = headers;
            window.currentCsvRows = rows;

            // ✅ Update token UI
            renderTokenPanel(headers);
            updateHighlight();

            populateColumnMappings(rows);

            // ✅ NEW: enable Next button if valid
            updateNextButtonState();
        };

        reader.readAsText(file);
    }

    function normaliseName(value) {
        return value
            .toLowerCase()
            .replace(/[_\-\s]/g, "")
            .replace(/[^a-z0-9]/g, "");
    }

    function findBestMatch(fieldName, headers) {

        const target = normaliseName(fieldName);

        // Synonym lookup first
        const synonyms = COLUMN_SYNONYMS[target];

        if (synonyms) {

            const synonymMatch = headers.find(header => {

                const headerName =
                    normaliseName(header);

                return synonyms.some(synonym =>
                    headerName === synonym ||
                    headerName.includes(synonym) ||
                    synonym.includes(headerName)
                );

            });

            if (synonymMatch) {
                return synonymMatch;
            }
        }

        // Exact match
        let match = headers.find(
            h => normaliseName(h) === target
        );

        if (match) return match;

        // Contains match
        match = headers.find(
            h => normaliseName(h).includes(target)
        );

        if (match) return match;

        // Reverse contains
        match = headers.find(
            h => target.includes(normaliseName(h))
        );

        return match || "";
    }

    const COLUMN_SYNONYMS = {
        sysid: [
            "sysid",
            "systemid"
        ],

        provisiondate: [
            "provisiondate",
            "dateprovided"
        ],

        pharmacistname: [
            "pharmacistname",
            "pharmacist"
        ],

        telephonenumber: [
            "telephone",
            "telephonenumber",
            "phone",
            "tel",
            "telnum"
        ],

        addorremove: [
            "add/remove",
            "action"
        ],

        allergicRhinitisAzelastine: ["Azelastine"],
        allergicRhinitisDymista: ["Dymista"],
        allergicRhinitisFexofenadine: ["Fexofenadine"],

        notificationstatus: [
            "notificationstatus",
            "privatpgdrequestnotificationstatus"
        ],

        recordstatus: [
            "recordclaimstatus",
            "recordstatus",
            "claimstatus"
        ],
        odscode: [
            "odscode",
            "ods_code",
            "organisationcode",
            "nhscode",
            "ods"
        ],

        firstname: [
            "firstname",
            "forename",
            "givenname"
        ],

        lastname: [
            "lastname",
            "surname",
            "familyname"
        ],

        email: [
            "email",
            "emailaddress",
            "secureemail"
        ],

        telephone: [
            "telephone",
            "phone",
            "phonenumber",
            "tel"
        ],

        proffesionalbody: [
            "professionalbody",
            "professionalorganisation",
            "professionalorganisationname"
        ],

        registrationnumber: [
            "registrationnumber",
            "registrationid",
            "registration"
        ],

        otheremail: [
            "otheremail",
            "secondaryemail",
            "alternateemail"
        ]
    };


    function populateColumnMappings(rows) {

        console.log("populateColumnMappings called");

        const container =
            document.getElementById("columnMappingsContainer");

        console.log("container", container);

        if (!container) return;

        container.innerHTML = "";

        const required =
            window.currentScriptMeta?.requiredColumns;

        console.log("requiredColumns", required);

        if (!required?.length) return;

        const headers = Object.keys(rows[0]);
        let autoMapped = 0;


        required.forEach(field => {

            const card = document.createElement("div");
            card.className = "mapping-card";

            const header = document.createElement("div");
            header.className = "mapping-header";

            const title = document.createElement("div");
            title.className = "mapping-title";
            title.textContent = field.label;

            header.appendChild(title);

            const label =
                document.createElement("label");

            label.textContent = field.label;

            const select =
                document.createElement("select");

            select.addEventListener("change", () => {

                if (!select.value) {
                    delete wizardData.columnMappings[field.key];
                    return;
                }

                wizardData.columnMappings[field.key] =
                    select.value;
            });

            select.dataset.key = field.key;

            headers.forEach(header => {

                const option =
                    document.createElement("option");

                option.value = header;
                option.textContent = header;

                select.appendChild(option);

            });

            const guess =
                findBestMatch(
                    field.key,
                    headers
                );

            if (!guess && !field.required) {
                select.value = "";
            }

            if (guess) {

                autoMapped++;

                select.value = guess;

                wizardData.columnMappings[field.key] = guess;

                const badge = document.createElement("span");
                badge.className = "mapping-badge";
                badge.textContent = "✓ Auto Matched";

                header.appendChild(badge);

            }
            else if (field.required) {

                const badge = document.createElement("span");
                badge.className = "mapping-badge warning";
                badge.textContent = "⚠ Required";

                header.appendChild(badge);
            }
            else if (!field.required) {
                select.value = "";
            }

            card.appendChild(header);
            card.appendChild(select);

            container.appendChild(card);

        });
        const requiredFields =
            required.filter(f => f.required);

        const matchedRequired =
            requiredFields.filter(f =>
                wizardData.columnMappings[f.key]
            ).length;

        const missingRequired =
            requiredFields.length - matchedRequired;

        const summary =
            document.getElementById("csvStatus");

        summary.innerHTML +=
            missingRequired === 0
                ? `✅ All ${requiredFields.length} required fields mapped`
                : `⚠ ${missingRequired} required fields need attention`;

        summary.classList.remove("hidden");

        console.log(
            "Mappings after auto-map:",
            JSON.stringify(
                wizardData.columnMappings,
                null,
                2
            )
        );
    }



    function normaliseKey(key) {
        return key.toLowerCase().replace(/[^a-z0-9]/g, "");
    }

    function buildHighlightedText(rawText, csvHeaders) {
        return rawText.replace(TOKEN_REGEX, (fullMatch, tokenName) => {
            const normalizedToken = normaliseKey(tokenName);

            const match = csvHeaders.some(h =>
                normaliseKey(h) === normalizedToken
            );

            if (match) {
                return `<span class="valid-token">${fullMatch}</span>`;
            }

            return `<span class="invalid-token">${fullMatch}</span>`;
        });
    }
    const textarea = inlineTextarea
    const highlight = document.getElementById("advancedEditorHighlight");

    document.addEventListener("click", (e) => {
        const tokenEl = e.target.closest(".invalid-token");
        if (!tokenEl) return;

        showTokenPicker(tokenEl);
        e.preventDefault();
        e.stopPropagation();
    });

    textarea.addEventListener("input", updateHighlight);

    function updateHighlight() {
        function updateHighlight() {
            console.log("[Highlight] update called");

            if (!highlight) {
                console.log("[Highlight] ❌ highlight missing");
                return;
            }

            if (!textarea) {
                console.log("[Highlight] ❌ textarea missing");
                return;
            }

            console.log("[Highlight] raw value:", textarea.value);

            const raw = textarea.value;

            const escaped = raw
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");

            console.log("[Highlight] escaped:", escaped);

            const highlighted = buildHighlightedText(escaped, csvHeaders);

            console.log("[Highlight] result:", highlighted);

            highlight.innerHTML = highlighted + "\n";
        }
    }

    function positionNear(anchorEl, popupEl) {
        const rect = anchorEl.getBoundingClientRect();

        popupEl.style.position = "absolute";
        popupEl.style.left = rect.left + window.scrollX + "px";
        popupEl.style.top = rect.bottom + window.scrollY + 6 + "px";
    }

    let activeTokenPicker = null;

    function removeTokenPicker() {
        if (activeTokenPicker) {
            activeTokenPicker.remove();
            activeTokenPicker = null;
        }
    }

    function showTokenPicker(tokenEl) {
        removeTokenPicker();

        if (!csvHeaders.length) {
            console.warn("No CSV headers, picker not shown");
            return;
        }

        const picker = document.createElement("div");
        picker.className = "token-picker";

        console.log("Picker appended", picker);


        csvHeaders.forEach(header => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.textContent = `{{ ${header} }}`;
            btn.addEventListener("click", () => {
                replaceToken(tokenEl.textContent, header);
                removeTokenPicker();
            });
            picker.appendChild(btn);
        });

        document.body.appendChild(picker);

        const rect = tokenEl.getBoundingClientRect();
        picker.style.position = "absolute";
        picker.style.left = rect.left + window.scrollX + "px";
        picker.style.top = rect.bottom + window.scrollY + 6 + "px";
        picker.style.zIndex = 2001;

        activeTokenPicker = picker;

        setTimeout(() => {
            document.addEventListener("click", onOutsideTokenPickerClick);
        }, 0);
    }

    function onOutsideTokenPickerClick(e) {
        if (e.target.closest(".token-picker")) return;
        if (e.target.closest(".invalid-token")) return;

        removeTokenPicker();
        document.removeEventListener("click", onOutsideTokenPickerClick);
    }

    function replaceToken(oldTokenText, newTokenName) {
        const newToken = `{ { ${newTokenName.toUpperCase()} } } `;

        textarea.value = textarea.value.replace(oldTokenText, newToken);

        updateHighlight();
        textarea.focus();
    }



    function parseCsvHeaders(csvText) {
        const firstLine = csvText.split(/\r?\n/)[0];
        if (!firstLine) return [];

        return firstLine
            .split(",")
            .map(normaliseHeader)
            .filter(Boolean);
    }

    initAdvancedHelp();
}

function applyScriptRequirements(script) {
    const envFileInput = document.getElementById("runnerEnvFile");
    const envFileField = envFileInput.closest(".field");

    const passInput = document.getElementById("decryptPassword");
    const passField = passInput.closest(".field");

    const csvInput = document.getElementById("csvFile");
    const csvField = csvInput.closest(".field");

    const optionsPanel = document.querySelector(".options-panel");
    const advancedPanel = document.getElementById("advancedPanel");

    if (advancedPanel) {
        if (script.advanced === true) {
            advancedPanel.style.display = "";
        } else {
            advancedPanel.style.display = "none";
        }
    }

    if (optionsPanel) {
        if (script.showOptionsPanel === false) {
            optionsPanel.style.display = "none";
        } else {
            optionsPanel.style.display = "";
        }
    }

    if (!script.requiresCsv) {
        csvField.style.display = "none";
        csvInput.required = false;
    } else {
        csvInput.required = true;
    }

    // CASE 1: Script requires env file
    if (script.requiresEnvFile) {
        envFileField.style.display = "";
        passField.style.display = "";
        envFileInput.required = true;
        passInput.required = true;
        return;
    }

    // CASE 2: Script optionally uses env file
    if (script.optionalEnvFile) {
        envFileField.style.display = "";
        passField.style.display = "";
        envFileInput.required = false;
        passInput.required = false;
        return;
    }

    // CASE 3: Script does not use env files
    envFileField.style.display = "none";
    passField.style.display = "none";
    envFileInput.required = false;
    passInput.required = false;
}

async function loadManifest(product) {
    const res = await fetch(`/api/products/${product}/manifest`);

    if (!res.ok) {
        throw new Error(`Failed to load manifest for ${product}`);
    }

    return await res.json();
}

function populateHeader(manifest, script) {
    const titleEl = document.getElementById("scriptTitle");
    titleEl.textContent = script.title || script.name || script.id;
}

function renderReview() {
    document.getElementById("reviewScriptName").textContent =
        window.currentScriptMeta?.title || scriptId;

    const script = window.currentScript;

    // Inputs
    const inputsEl = document.getElementById("reviewInputs");
    inputsEl.innerHTML = "";

    if (window.currentScriptMeta?.inputs) {
        window.currentScriptMeta.inputs.forEach(input => {
            const value = wizardData.inputs[input.key] || "—";

            const row = document.createElement("div");
            row.textContent = `${input.label}: ${value}`;
            inputsEl.appendChild(row);
        });
    }

    const optionsSection = document.getElementById("reviewOptionsSection");
    const optionsEl = document.getElementById("reviewOptions");

    if (script?.showOptionsPanel) {
        optionsSection.style.display = "";

        const content = [];

        const dryRunEl = document.getElementById("dryRunCheckbox");
        if (dryRunEl?.checked) content.push("Dry run enabled");

        const showBrowserEl = document.getElementById("showBrowser");
        if (showBrowserEl?.checked) content.push("Browser visible");

        const recordVideoEl = document.getElementById("recordVideo");
        if (recordVideoEl?.checked) content.push("Recording video");

        const recordTraceEl = document.getElementById("recordTrace");
        if (recordTraceEl?.checked) content.push("Recording trace");

        optionsEl.innerHTML =
            content.length > 0 ? content.join("<br>") : "Default behaviour";

    } else {
        optionsSection.style.display = "none";
    }

}

async function populateDescription(product, script) {
    const descEl = document.getElementById("descriptionContent");

    try {
        const res = await fetch(`/api/products/${product}/scripts/${script.id}/description`);
        if (res.ok) {
            const markdown = await res.text();
            descEl.innerHTML = marked.parse(markdown);
        } else {
            descEl.textContent = "No description available.";
        }
    } catch (err) {
        console.error("Failed to load description:", err);
        descEl.textContent = "Failed to load description.";
    }
}

function handleEvent(event) {
    switch (event.event) {

        case LoggerEvent.ROW_START:
            updateProgress(event.current, event.total);
            updateCurrentOds(event.odsCode);
            updateCurrentStep("Starting...");
            break;

        case LoggerEvent.LOGIN:
            updateCurrentStep("🔐 Logging in...");
            break;

        case LoggerEvent.OPEN_PROVIDER:
            updateCurrentStep("🏥 Opening provider...");
            break;

        case LoggerEvent.ACCREDIT:
            updateCurrentStep("✅ Accrediting...");
            break;

        case LoggerEvent.ROW_COMPLETE:
            updateCurrentStep("✅ Complete");
            break;

        case LoggerEvent.RUN_COMPLETE:
            updateStatus("Completed ✅");

            if (runTimer) {
                clearInterval(runTimer);
                runTimer = null;
            }

            break;
    }
}

function appendLogEntry(entry) {
    if (entry.type === "event") {
        handleEvent(entry);
        return;
    }

    const div = document.createElement("div");
    div.classList.add("log-entry");

    const time = new Date(entry.time).toLocaleTimeString();
    const line = entry.line;
    let levelClass = "log-info";

    if (line.includes("✅")) levelClass = "log-success";
    else if (line.includes("❌")) levelClass = "log-error";
    else if (line.includes("🔍")) levelClass = "log-action";
    else if (line.includes("👤")) levelClass = "log-user";
    else if (line.includes("🔧") || line.includes("🛠")) levelClass = "log-job";

    div.classList.add(levelClass);

    div.innerHTML = `
        <span class="log-time">${time}</span>
        <span class="log-text">${escapeHtml(line)}</span>
    `;

    logContainer.appendChild(div);
    logContainer.scrollTop = logContainer.scrollHeight;
}

function startLogStream(runId) {
    const evtSource = new EventSource(`/api/run/${runId}/logs`);

    evtSource.addEventListener("log", (event) => {
        const entry = JSON.parse(event.data);
        appendLogEntry(entry);
    });

    evtSource.addEventListener("run:finished", (event) => {
        const data = JSON.parse(event.data);
        console.log("✅ Run finished", data);
    });

    evtSource.onerror = (err) => {
        console.error("Log stream error:", err);
        evtSource.close();
    };

    evtSource.onopen = () => {
        console.log("✅ Log stream connected");
    };
}

async function startRun(product, script, formData) {
    const status = document.getElementById("runStatus");

    if (status) {
        status.textContent = "Starting run…";
    }

    updateCurrentOds("—");
    updateCurrentStep("Starting...");
    updateProgress(0, 0);
    updateStatus("Running...");

    const startTime = new Date();

    document.getElementById("metaStart").textContent =
        startTime.toLocaleTimeString();

    const durationEl = document.getElementById("metaDuration");

    if (runTimer) clearInterval(runTimer); // safety reset

    runTimer = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTime) / 1000);

        const mins = Math.floor(elapsed / 60);
        const secs = elapsed % 60;

        document.getElementById("metaDuration").textContent =
            `${mins}:${secs.toString().padStart(2, "0")}`;
    }, 1000);


    try {
        const res = await fetch(
            `/api/run/${encodeURIComponent(product)}/${encodeURIComponent(script.id)}`,
            {
                method: "POST",
                body: formData,
                credentials: "include"
            }
        );

        const data = await res.json().catch(() => ({}));

        if (!res.ok) {
            console.error("Run start error:", data);

            if (status) {
                status.textContent = data.error || "Run failed to start.";
            }

            // Hide stop button — run never started
            document.getElementById("stopRunContainer")?.classList.add("hidden");
            return;
        }

        if (status) {
            status.textContent = data.message || "Run started.";
        }

        if (data.runId) {
            window.currentRunId = data.runId;

            startLogStream(data.runId);

            // Show stop button
            document.getElementById("stopRunContainer")?.classList.remove("hidden");
        }

    } catch (err) {
        console.error("Run failed:", err);

        if (status) {
            status.textContent = "Run failed.";
        }

        document.getElementById("stopRunContainer")?.classList.add("hidden");
    } finally {
        // Clear password after run
        const passEl = document.getElementById("decryptPassword");
        if (passEl) passEl.value = "";
    }
}

function enterExecutionMode() {
    console.log("Entering execution mode");

    const root = document.getElementById("runnerRoot");
    const wizard = document.getElementById("wizardContainer");
    const execution = document.getElementById("executionContainer");


    updateStatus("Starting...");
    updateCurrentOds("—");
    updateCurrentStep("Starting...");
    updateProgress(0, 0);


    // Ensure layout switches to execution view if needed
    if (root) {
        root.classList.remove("wizard-mode");
    }

    // Hide wizard UI
    if (wizard) {
        wizard.classList.add("hidden");
    }

    // Show execution/logs UI
    if (execution) {
        execution.classList.remove("hidden");
    }
}

function setupRunForm(product, script) {

    const form = document.getElementById("run-form");
    if (!form) {
        console.warn("run-form not found");
        return;
    }

    const envFileInput = document.getElementById("runnerEnvFile");
    const csvFileInput = document.getElementById("csvFile");
    const advancedStepsEl = document.getElementById("advancedSteps");
    const stopRunButton = document.getElementById("stopRunButton");

    if (stopRunButton) {
        stopRunButton.addEventListener("click", async () => {
            if (!currentRunId) return;

            stopRunButton.disabled = true;
            stopRunButton.textContent = "Stopping…";

            await fetch(`/api/run/${currentRunId}/stop`, {
                method: "POST",
                credentials: "include"
            });

            if (runTimer) {
                clearInterval(runTimer);
                runTimer = null;
            }

            stopRunButton.textContent = "Stopping…";
        });
    } else {
        console.warn("stopRunButton not present (expected before execution)");
    }

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        enterExecutionMode();

        const dryRunCheckbox = document.getElementById("dryRunCheckbox");
        const missingMappings =
            (script.requiredColumns || [])
                .filter(
                    column =>
                        !wizardData.columnMappings?.[column]
                );

        if (missingMappings.length > 0) {

            alert(
                `Please map: ${missingMappings.join(", ")}`
            );

            return;
        }

        const options = {
            autoScrollLogs: true,

            // ALWAYS present
            dryRun: document.getElementById("dryRunCheckbox")?.checked ?? false,

            // Optional UI features
            showBrowser: document.getElementById("showBrowser")?.checked ?? false,
            recordVideo: document.getElementById("recordVideo")?.checked ?? false,
            recordTrace: document.getElementById("recordTrace")?.checked ?? false,
        };

        const formData = new FormData();

        console.log(
            "Submitting mappings:",
            JSON.stringify(
                wizardData.columnMappings,
                null,
                2
            )
        );

        formData.append("columnMappings", JSON.stringify(wizardData.columnMappings));
        console.log("FormData columnMappings:", wizardData.columnMappings);
        if (script.advanced && advancedStepsEl?.value.trim()) {
            formData.append("advancedSteps", advancedStepsEl.value.trim());
        }

        if (envFileInput?.files?.length) {
            formData.append("envFile", envFileInput.files[0]);
        }

        if (csvFileInput?.files?.length) {
            formData.append("csvFile", csvFileInput.files[0]);
        }

        const passphrase = document.getElementById("decryptPassword")?.value;
        if (passphrase) {
            formData.append("passphrase", passphrase);
        }

        formData.append("options", JSON.stringify(options));

        if (window.currentScriptMeta?.inputs) {
            window.currentScriptMeta.inputs.forEach(input => {
                const value = wizardData.inputs[input.key];

                if (value !== undefined) {
                    formData.append(input.key, value);
                }
            });
        }

        await startRun(product, script, formData);
    });
}

function updateStatusAndArtifacts(jobData) {
    const status = jobData.status;
    const runDirName = jobData.runDirName;

    if (status === "queued") {
        const posText =
            jobData.position && jobData.position > 0
                ? ` You are #${jobData.position} in the queue.`
                : "";
        runStatus.textContent = `Run #${jobData.id} queued.${posText}`;
    } else if (status === "running") {
        runStatus.textContent = `Run #${jobData.id} is in progress...`;
    } else if (status === "completed") {
        runStatus.textContent = `Run #${jobData.id} completed.`;
    } else if (status === "failed") {
        runStatus.textContent = `Run #${jobData.id} failed. Check logs.`;
    }

    artifactList.innerHTML = "";
    if (!runDirName) return;

    const baseUrl = `/runs/${window.scriptFolder}/${runDirName}`;

    const items = [
        {
            label: "Results CSV",
            href: `${baseUrl}/UsersAdded.csv`,
        },
        {
            label: "Trace file",
            href: `${baseUrl}/trace.zip`,
        },
    ];

    items.forEach((item) => {
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = item.href;
        a.textContent = item.label;
        a.target = "_blank";
        li.appendChild(a);
        artifactList.appendChild(li);
    });

    // Fetch video list dynamically
    fetch(`/api/videos/${window.scriptFolder}/${runDirName}`)
        .then(res => res.json())
        .then(files => {
            if (!files.length) return;

            const videosHeader = document.createElement("li");
            videosHeader.textContent = "Videos:";
            artifactList.appendChild(videosHeader);

            files.forEach(file => {
                const li = document.createElement("li");
                const a = document.createElement("a");

                a.href = `/runs/${window.scriptFolder}/${runDirName}/videos/${file}`;
                a.textContent = file;
                a.target = "_blank";

                li.appendChild(a);
                artifactList.appendChild(li);
            });
        })
        .catch(err => console.error("Video fetch error:", err));
}

function resetUI() {
    currentJobId = null;
    lastLogLength = 0;
    logContainer.innerHTML = "";
    artifactList.innerHTML = "";
    queueList.innerHTML = "";
    runStatus.textContent = "";
}

function escapeHtml(text) {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function updateStatus(text) {
    document.getElementById("metaStatus").textContent = text;
}

function updateProgress(current, total) {
    const percent = total ? (current / total) * 100 : 0;

    document.getElementById("progressText").textContent =
        `${current} / ${total}`;

    document.getElementById("progressFill").style.width =
        `${percent}%`;
}

function updateCurrentOds(ods) {
    document.getElementById("currentOds").textContent = ods;
}

function updateCurrentStep(step) {
    document.getElementById("currentStep").textContent = step;
}

